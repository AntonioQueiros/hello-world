'''
Este script pega no output do "sh int" nas firwall ASA ou FWSM e
obtem:
# FW hostname; FW Context; Interface; Nome Interface; IP GW; Rede/Mascara
e coloca uma linha separada por ';' (ou seja CSVSEP) , por cada interface

Nesta altura nao faz verificacoes de introducao de dados errados, por isso
deve ser como input excatamente o output do "show int".

LFR 2013.03.05

LFR 2013.04.15 - Interface Grafica - Tkinter
'''
from Tkinter import * # LFR
from ScrolledText import ScrolledText 


DEB=1
CSVSEP=';'

#=================================================================================
# Print debug info, if it's in debug mode.
#=================================================================================
def debug(dbg, str_dbg):
  if dbg:
    print (str_dbg,)
  return

#=================================================================================
# return a mask of n bits as a long integer
#=================================================================================
def maskBIN(n):
    "return a mask of n bits as a long integer"
    return ((2**n-1)<<32-n)

#=================================================================================
# Convert a dotted IP address to a number
#=================================================================================
def dotIP2int(ip):
    "Convert a dotted IP address to a number"
    strip=ip.split('.',3)
    return ((int(strip[0])*256+(int(strip[1])))*256+int(strip[2]))*256+int(strip[3])

#=================================================================================
# Convert a numbered IP address to a dotted string
#=================================================================================
def intIP2dot(ip):
    "Convert a numbered IP address to a dotted string"
    return str((ip>>24)&255)+"."+ \
           str((ip>>16)&255)+"."+ \
           str((ip>>8)&255) +"."+ \
           str(ip&255)

#=================================================================================
# Is an address in a network
#=================================================================================
def addressInNetwork(ip,net,mask):
   "Is an address in a network"
   return (ip & mask) == net



#=========================================================================================
# ------------ GUI
def showINT(STRFW, STRCTX, INTout):
    
    INTresult = Tk()
    INTresult.title("Firewall Interfaces CSV "+STRFW+"/"+STRCTX)

    #
    #
    # Text Box
    INTtx=ScrolledText(INTresult, width=120, font=("Courier", 8))
    INTtx.grid(row=0, column=0)
    #
    INTtx.insert('1.0', INTout)
    #
    #Button(ACEresult, text='Quit', command=ACEresult.quit).grid(row=2, column=0, sticky=W, pady=4)
    return
      

#=================================================================================
# fwINT
#=================================================================================
def fwINT ():
  
  #debug(DEB,"IT>>\n"+STRSI)
  print '\n\nFWINT:\n',
  
  STRFW=STRFWval.get() # nome da firewall
  STRCTX=STRCTXval.get() # contexto da firewall
  STRSI=STRSItx.get(1.0,END) # "show interface" 

  STRLN=STRSI.splitlines()
  STRLG=len(STRLN)

  '''
  Interface Port-channel3.1032 "PSP-PDOI-PRD-WEB-FE", is up, line protocol is up
          MAC address 00a0.c927.0201, MTU 1500
          IP address 10.162.101.145, subnet mask 255.255.255.240
    Traffic Statistics for "PSP-PDOI-PRD-WEB-FE":
          1462123 packets input, 93494561 bytes
          51221 packets output, 15101597 bytes
          1403542 packets dropped
  '''
  
  INTERFACE=False
  IP_ADDRESS=False
  INTout=''
  print "START\n\n"
  for STRL in STRLN:
    print "LINEin:",
    print STRL
    # Interface
    if ("Interface" in STRL):   # ASA:  Interface Port-channel3.1032 "PSP-PDOI-PRD-WEB-FE", is up, line protocol is up
      STRIL=STRL.split(' ')     # FWSM: Interface Vlan3422 "AWSTATS-FE", is up, line protocol is up
      STRILI1=STRIL[1]             # ASA/FWSM: Port-channel3.1032 / Vlan3422
      STRILI2=STRIL[2].strip('",') # "PSP-PDOI-PRD-WEB-FE", # -> PSP-PDOI-PRD-WEB-FE
      INTERFACE=True
      # Obter o VLAN ID
      if ("Vlan" in STRILI1 ):         # ASA
        STRILI1VLAN=STRILI1.strip('Vlan')
      if ("Port-channel" in STRILI1 ): # FWSM
        STRILI1VLAN=STRILI1.split('.')[1]
      
    # IP address line option:
    # '012345678 9      10             11     12   13
    # '        IP address 10.163.2.149, subnet mask 255.255.255.0'
    # '        Available but not configured via nameif'
    if (("IP address" in STRL) and not (("unassigned" in STRL) or ("Available but not configured") in STRL)): 
      STRIPADDR=STRL.split(' ')                                 # '        IP address unassigned'
      # Obter o endreco IP da GW
      STRADDR1=STRIPADDR[10].strip(',') # 10.162.101.145, # -> '10.162.101.145' IP da Gateway
      # Obter a mascara de rede
      STRADDR2=STRIPADDR[13]            # 255.255.255.240 # Mascara de rede
      # Calcular a rede
      STRADDR3=intIP2dot(dotIP2int(STRADDR1) & dotIP2int(STRADDR2)) # Network
      IP_ADDRESS=True

    # Imprimir Resultados, not GUI
    if (INTERFACE and IP_ADDRESS):
      # FW hostname; FW Context; Interface; Nome Interface; IP GW; Rede/Mascara
      #     IP GW               ;      IP rede              /  MASK                ;      FW    ;      CTX    ;      NOME INT           ;      VLAN        #  ;      NOME INT.VLAN
      INTline=STRADDR1.strip(' ')+CSVSEP+STRADDR3.strip(' ')+"/"+STRADDR2.strip(' ')+CSVSEP+STRFW+CSVSEP+STRCTX+CSVSEP+STRILI2.strip(' ')+CSVSEP+STRILI1VLAN # +CSVSEP+STRILI1.strip(' ')
      print "LINEout:",INTline
      INTout+=INTline+'\n'
      INTERFACE=False
      IP_ADDRESS=False
  #
  print "\nLINEso: "
  print INTout
  showINT(STRFW, STRCTX, INTout) # Apresento o resultado em CSV --- GUI.
  return
      


      
    
#=========================================================================================
# main
#=========================================================================================
# ------------ GUI
print ">>>1"
master = Tk()
master.title("Read FW interfaces")
print ">>>2"
#
# Obter o nome FW e CTX ---------------------------
STRFWlb=Label(master, text="HOSTNAME FW: ")
STRCTXlb=Label(master, text="CONTEXT FW: ")
STRFWlb.grid(row=0, column=0, sticky=E)
STRCTXlb.grid(row=1, column=0, sticky=E)
#
STRFWval=Entry(master)
STRCTXval=Entry(master)
STRFWval.grid(row=0, column=1, sticky=W)
STRCTXval.grid(row=1, column=1, sticky=W)
#
#
# Obter a INT ----------------------------
# ScrolledText Box
STRSItx=ScrolledText(master, width=120, font=("Courier", 8))
STRSItx.grid(row=2, column=0, columnspan=2)
#
#
Button(master, text='Quit', command=master.quit).grid(row=3, column=0, sticky=E, pady=4)
Button(master, text='Submit', command=fwINT).grid(row=3, column=1, sticky=W, pady=4) # (STRFWval, STRCTXval, STRSItx.get(1.0,END))
#Button(master, text='Show', command=show_entry_fields).grid(row=3, column=2, sticky=W, pady=4)
#
mainloop( )




